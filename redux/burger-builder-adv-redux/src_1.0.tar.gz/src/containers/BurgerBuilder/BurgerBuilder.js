import React, { Component } from 'react';
import Aux from '../../hoc/Aux'
import Burger from '../../components/Burger/Burger';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/Burger/OrderSummary/OrderSummary';
const INGRIDENTS_PRICES = {
    'salad': .5,
    'cheese': .6,
    'bacon': .7,
    'meat': 1.2
}
class BurgerBuilder extends Component {
    state = {
        ingredients: {
            'salad': 0,
            'cheese': 0,
            'bacon': 0,
            'meat': 0
        },
        totalPrice: 4,
        purchasable: false,
        purchasing: false
    }
    purchaseHandler = () => {
        this.setState({ purchasing: true });
    }
    cancelPurchaseHandler = () => {
        this.setState({ purchasing: false });
    }
    continuePurchaseHandler = () => {
        alert('you should continue');
    }
    updatePurchaseAbleState(ingredients) {
        const sum = Object.keys(ingredients).map(igKey => {
            return ingredients[igKey];
        }).reduce((sum, el) => {
            return sum + el;
        }, 0);
        this.setState({ purchasable: sum > 0 });
    }
    addIngridentsHandler = (type) => {
        const updatedIngredients = { ...this.state.ingredients };
        updatedIngredients[type]++;
        const newTotalPrice = this.state.totalPrice + INGRIDENTS_PRICES[type];
        this.setState({ ingredients: updatedIngredients, totalPrice: newTotalPrice });
        this.updatePurchaseAbleState(updatedIngredients);
    }
    removeIngredientsHandler = (type) => {
        if (this.state.ingredients[type] <= 0) {
            return;
        }
        const updatedIngredients = { ...this.state.ingredients };
        updatedIngredients[type]--;
        const newTotalPrice = this.state.totalPrice - INGRIDENTS_PRICES[type];
        this.setState({ ingredients: updatedIngredients, totalPrice: newTotalPrice });
        this.updatePurchaseAbleState(updatedIngredients);
    }
    render() {
        const disabledInfo = { ...this.state.ingredients };
        for (let key in disabledInfo) {
            disabledInfo[key] = disabledInfo[key] <= 0;
        }
        return (
            <Aux>
                <Modal show={this.state.purchasing} cancelPurchase={this.cancelPurchaseHandler}>
                    <OrderSummary ingredients={this.state.ingredients}
                        purchaseCancelled={this.cancelPurchaseHandler}
                        continuePurchase={this.continuePurchaseHandler}
                        price={this.state.totalPrice} />
                </Modal>
                <Burger ingredients={this.state.ingredients} />
                <BuildControls
                    ingredientAdded={this.addIngridentsHandler}
                    ingredientRemoved={this.removeIngredientsHandler}
                    disabled={disabledInfo}
                    price={this.state.totalPrice}
                    purchasable={this.state.purchasable}
                    ordered={this.purchaseHandler} />
            </Aux>

        );

    }
}

export default BurgerBuilder;